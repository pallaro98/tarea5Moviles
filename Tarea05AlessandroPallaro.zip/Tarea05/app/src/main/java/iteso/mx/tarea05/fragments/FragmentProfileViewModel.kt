package iteso.mx.tarea05.fragments

import androidx.lifecycle.ViewModel

class FragmentProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
