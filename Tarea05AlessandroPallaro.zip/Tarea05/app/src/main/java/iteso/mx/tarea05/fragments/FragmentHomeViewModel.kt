package iteso.mx.tarea05.fragments

import androidx.lifecycle.ViewModel

class FragmentHomeViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
