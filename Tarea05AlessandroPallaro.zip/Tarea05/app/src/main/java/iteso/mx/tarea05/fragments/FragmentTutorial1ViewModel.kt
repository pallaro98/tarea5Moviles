package iteso.mx.tarea05.fragments

import androidx.lifecycle.ViewModel

class FragmentTutorial1ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
