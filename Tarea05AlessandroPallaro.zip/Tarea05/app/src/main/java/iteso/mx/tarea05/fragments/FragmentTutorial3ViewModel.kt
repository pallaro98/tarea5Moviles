package iteso.mx.tarea05.fragments

import androidx.lifecycle.ViewModel

class FragmentTutorial3ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
