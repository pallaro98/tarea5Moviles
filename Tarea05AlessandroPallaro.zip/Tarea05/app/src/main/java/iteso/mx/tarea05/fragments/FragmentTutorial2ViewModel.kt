package iteso.mx.tarea05.fragments

import androidx.lifecycle.ViewModel

class FragmentTutorial2ViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
